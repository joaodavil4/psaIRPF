﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IrpfApp.BLL
{
    public class DeclaracaoIrpf 
    {
  //      public int DeclaracaoIrpfID { get; set;  }
   


  //      private String cpf;
  //      private int idade;
  //      private int nroDep;
  //      private double contrPrev;
  //      private bool status;
  //      private CalculoIrpf impostoDevido;

  //      public DeclaracaoIrpf(String nome, String cpf, int idade,
  //                          int nroDep, double contrPrev, bool status)
  ////                      throws IllegalArgumentException
  //      {
        
        
  //      this.contrPrev = contrPrev;
  //      this.cpf = cpf;
  //      this.idade = idade;
        
  //      this.NroDep = nroDep;
  //      this.status = status;
  //      this.impostoDevido = new CalculoIrpfSimplificado(); // Assume como default
  //  }

  //  public void defineCalculo(CalculoIrpf calc)
  //  {
  //      impostoDevido = calc;
  //  }


  //  public override String ToString()
  //  {
  //      StringBuilder sb = new StringBuilder();
  //      sb.Append(cpf);
  //      sb.Append(",");
  //      sb.Append(idade);
  //      sb.Append(",");
  //      sb.Append(NroDep);
  //      sb.Append(",");
  //      sb.Append(contrPrev);
  //      sb.Append(",");
  //      sb.Append(status);
  //      return (sb.ToString());
  //  }

  //  public double getContrPrev()
  //  {
  //      return contrPrev;
  //  }

  //  public String getCpf()
  //  {
  //      return cpf;
  //  }

  //  public int Idade
  //  {
  //      get { return idade; }
  //      set { idade = value;  }
  //  }

  //  //public void setIdade(int novaIdade)
  //  //    {
  //  //        idade = novaIdade;
  //  //    }

       

  //  public int NroDep { get; set; }
        
  //  public bool getTotRend()
  //  {
  //      return status;
  //  }

  //  public double getImpostoDevido()
  //  {
  //      return (impostoDevido.calculaImposto(this));
  //  }
}
}
