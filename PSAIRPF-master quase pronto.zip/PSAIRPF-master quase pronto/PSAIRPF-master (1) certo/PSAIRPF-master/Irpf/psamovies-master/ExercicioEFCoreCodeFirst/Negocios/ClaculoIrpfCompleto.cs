﻿using ExercicioEFCoreCodeFirst;
using System;
using System.Collections.Generic;
using System.Text;

namespace IrpfApp.BLL
{
    public class CalculoIrpfCompleto : CalculoIrpf
    {
        int cpf;
        double dependentes;
        double rendim;
        double imposto;
        double pagar;
        double prev;
        public CalculoIrpfCompleto(int cpf)
        {
            this.cpf = cpf;
        }

        public double calculaImposto()
        {
            IrpfFachada fachada = new IrpfFachada();

            Contribuinte contrib = fachada.buscarContribuinte(cpf);
            Declaracao decl = fachada.buscarDeclaracao(contrib.ContribuinteID);
            if (decl == null) { 
                
                return 400;
        }
            int dep = decl.NmroDependentes;

            dependentes = dep * 2275;

            prev = decl.Previdencia;

            double soma = 0;
            foreach (Deducao d in decl.Deducoes)


            {

               soma += d.Valor;
               
            }


            soma += dependentes;
            soma += prev;

            rendim = decl.RendimentoTrib;

            imposto = rendim - soma;
            if (imposto <= 22847)
            {
                pagar =0;
            }
            else if (imposto-22847<= 11072)
            {
                pagar = 830.40;
               
            }
            else if (imposto - 22847- 11072 <= 11092)
            {
                pagar = 2494.32;
            }
            else if (imposto - 22847 - 11072 - 11092 <= 10963)
            {
                pagar = 4961;
               
            }
            else if (imposto - 22847 - 11072 - 11092 >= 10963)
            {
                pagar = imposto * 0.275 + 4961.12;
                
            }

            return pagar;
           
        }


    }
}
