﻿using System;
using System.Collections.Generic;
using System.Text;
using ExercicioEFCoreCodeFirst;

namespace IrpfApp.BLL
{
    public enum TipoCalculo
    {
        COMPLETO, SIMPLIFICADO
    }
}
