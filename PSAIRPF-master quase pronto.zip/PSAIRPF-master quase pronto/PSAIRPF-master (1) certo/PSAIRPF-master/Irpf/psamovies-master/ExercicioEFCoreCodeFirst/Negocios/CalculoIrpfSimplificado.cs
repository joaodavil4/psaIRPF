﻿using ExercicioEFCoreCodeFirst;
using System;
using System.Collections.Generic;
using System.Text;

namespace IrpfApp.BLL
{
    public class CalculoIrpfSimplificado: CalculoIrpf
    {
        int cpf;
        double pagar;
        double imposto;
        public CalculoIrpfSimplificado(int cpf)
        {
            this.cpf = cpf;
        }


        public double calculaImposto()
    {
            IrpfFachada fachada = new IrpfFachada();

            Contribuinte contrib = fachada.buscarContribuinte(cpf);
            Declaracao decl = fachada.buscarDeclaracao(contrib.ContribuinteID);
            if (decl == null)
            {

                return 400;
            }

            if (imposto * 0.20 >16754)
            {
                pagar = 16754;
            }
            else
            {
                pagar = imposto * 0.20;
            }


            ContribuinteDAO declaracoes = new BaseDados();
            Declaracao dec = declaracoes.adicionarImposto(pagar,cpf);
            return 0;

        }
}

}
