﻿using IrpfApp.BLL;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExercicioEFCoreCodeFirst
{
    public class AppConsole
    {
        public static void Main()
        {
            IrpfFachada fachada = new IrpfFachada();

            Declaracao decl = fachada.buscarDeclaracao(28/09/2019);

            if (decl == null) 
               Console.WriteLine("napo encontrado");
            else
                Console.WriteLine(decl);


            Console.ReadKey();
        }
    }
}
