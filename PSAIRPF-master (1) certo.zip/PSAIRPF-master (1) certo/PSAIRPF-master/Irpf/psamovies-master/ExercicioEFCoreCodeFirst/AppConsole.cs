﻿using IrpfApp.BLL;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExercicioEFCoreCodeFirst
{
    public class AppConsole
    {
		public static void Main()
		{
			IrpfFachada fachada = new IrpfFachada();

			Contribuinte contrib = fachada.buscarContribuinte(5);

			if (contrib == null)
				Console.WriteLine("napo encontrado");
			else
			{
				Console.WriteLine(contrib.FirstName);
				Declaracao decl = fachada.buscarDeclaracao(contrib.ContribuinteID);

				if (decl == null)
					Console.WriteLine("declaracao nao encontrado");
				else
				{
					Console.WriteLine(decl.Deducoes);

					 double soma=0;
					foreach (Deducao d in decl.Deducoes)
					
						
					{
                    
						soma += d.Valor;
						Console.WriteLine("\t" + d.Valor);
						

					}
					Console.WriteLine("------------------");
					Console.WriteLine(soma);


				}
				// decl.Status = true;
				// fachada.save(decl)
			}



			Console.ReadKey();
		}   
    }
}
