﻿using ExercicioEFCoreCodeFirst;
using System;
using System.Collections.Generic;
using System.Text;

namespace IrpfApp.BLL
{
    public class CalculoIrpfCompleto : CalculoIrpf
    {
        int cpf;

        public CalculoIrpfCompleto(int cpf)
        {
            this.cpf = cpf;
        }

        public double calculaImposto()
        {
            IrpfFachada fachada = new IrpfFachada();

            Contribuinte contrib = fachada.buscarContribuinte(5);
            Declaracao decl = fachada.buscarDeclaracao(contrib.ContribuinteID);
            double soma = 0;
            foreach (Deducao d in decl.Deducoes)


            {

               soma += d.Valor;
               
            }


            //if (rendaAnual <= 13968)
            //{
            //    Aliquota = 0;
            //    IR = ((rendaAnual - soma) * Aliquota);
            //}
            //else if (rendaAnual > 13968.01 && rendaAnual < 27912)
            //{
            //    Aliquota = 15 / 100;
            //    IR = ((rendaAnual - soma) * Aliquota);
            //}
            //else
            //{
            //    Aliquota = 27.5 / 100;
            //    IR = ((rendaAnual - soma) * Aliquota);
            //}


            //return IR;
            return 0;

        }


    }
}
