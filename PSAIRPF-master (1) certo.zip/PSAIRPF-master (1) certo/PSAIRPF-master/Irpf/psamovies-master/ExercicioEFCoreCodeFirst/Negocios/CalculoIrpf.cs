﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IrpfApp.BLL
{
    public interface CalculoIrpf
    {
        double calculaImposto();
    }
}
